console.log("LOAD")

document.onload = function () {
    var t = document.getElementById("top")
    console.log(t.isDom)
}
